({
	 init : function (component,event) {
        // Find the component whose aura:id is "flowData"
        var flow = component.find("flowData");
        var recId = component.get("v.recId");
         var inputVariables = [
             {
                 name : 'OpportunityId',
                 type : 'String',
                 value : recId
             }         
         ];
         // In that component, start your flow. Reference the flow's Unique Name.
         flow.startFlow("Create_Contact",inputVariables);                  
    },
    statusChange : function (component, event,helper) {
        if (event.getParam('status') === "FINISHED") {
          var showToast = $A.get("e.force:showToast"); 
            showToast.setParams({ 
                'title' : 'Custom Toast!', 
                'message' : 'The event has fired sucessfully.' 
            }); 
            showToast.fire();
            component.set("v.isModal",false);
        }
  },
  
})