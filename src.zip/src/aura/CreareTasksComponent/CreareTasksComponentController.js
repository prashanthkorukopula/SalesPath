({
	clickCreate : function(component, event, helper) {
        //create the new Task
        var newTask = component.get("v.newTask");
        var recId = component.get("v.recordId");
        var action = component.get("c.saveTask");
        action.setParams({
            "task":newTask,
            recordId:recId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                var showToast = $A.get("e.force:showToast"); 
                showToast.setParams({ 
                    'title' : 'Success', 
                    'message' : 'Task created sucessfully.' 
                }); 
                showToast.fire();
            }else{
                console.log("error :",state);
            }
        });
        $A.enqueueAction(action);
        
	},
})