({
	/* Method Name: handleSuccess
     * Description: helper method to fire event for handling after success and after cancel functionalities
	 */
	fireFormEvent : function(component, event, helper) {
		// Generic Form Event for handling form on success and save functionalties
		var formEvent = component.getEvent("ViewFormButtonAction");
		var sourceId = eventa.getSource().getLocalId();
		// Set the button label 
		formEvent.setParams({
			SourceName: event.getSource().getLocalId(),
			Mode: "View"
		});
		// Firing the component Evenet
		formEvent.fire();
	}
})