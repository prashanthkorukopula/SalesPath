({
	/* Method Name: handleEdit
     * Description: Controller method to handle edit button click
	 */
	handleEdit : function(component, event, helper) {
		helper.fireFormEvent(component, event, helper);
	}
})