({
	doInit : function(component, event, helper) {
        // Action to call backend metadata
		var actionSalesPath = component.get("c.getData");
        // Callback function 
        actionSalesPath.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var responseSalesPath = response.getReturnValue();
                console.log('--responseSalesPath--',responseSalesPath);
                component.set("v.salesPathMetaData", response.getReturnValue());
                component.set("v.lstStages", responseSalesPath.lstSalesPathStages);
                component.set("v.lstSalesPathData", responseSalesPath.mapSectionData['Open-Qualified']);
                component.set("v.baseUrl",responseSalesPath.baseURL);
            }
            else{
                console.log(response.getError());
            }
        });
        $A.enqueueAction(actionSalesPath);
		
	},
    sectionOne : function(component, event, helper) {
		var chevron = component.find('articleOne');
        var sectiondetails = component.find('path-content');
        for (var cmp in chevron) {
			$A.util.toggleClass(chevron[cmp], 'slds-show');
			$A.util.toggleClass(chevron[cmp], 'slds-hide');
		}
        $A.util.toggleClass(sectiondetails, 'slds-hide');
		$A.util.removeClass(sectiondetails, 'slds-show');
	},
    selectstage: function(component, event, helper) {
        var metaData = component.get("v.salesPathMetaData");
        console.log('--metaData--',metaData);
        var src = event.srcElement.outerText;
        if (src.includes('\n')) {
            var clickedStage = src.split('\n');
            src = clickedStage[2];
        }
        var listSection = metaData.mapSectionData[src];
        listSection.sort(function(a,b){return a['sectionOrder']-b['sectionOrder'] ;});
        component.set("v.lstSalesPathData",listSection);
	},
    HandleUserActionsEvent : function(component,event,helper){
        var rowData = event.getParam("rowWrapper");
        var lstComponents = rowData.lstComponentData;
        if(lstComponents != null && lstComponents.length > 0 ){
            for(var i=0; i< lstComponents.length ; i++ ){
                if(lstComponents[i].actionType != null && lstComponents[i].actionType.length > 0){
                    component.set("v.action",lstComponents[i].actionType);
                    if(lstComponents[i].actionType == 'Create Record'){
                        component.set("v.objectApiName",lstComponents[i].sObjectName);
                        if(lstComponents[i].sObjectName == 'Case'){
                            var flds = ["ContactId","Status","Subject","Description"];
                        }else{
                            var flds = ["Name","Phone","Website","AccountNumber"];
                        }                    
                        component.set("v.lstFields",flds);
                        component.set("v.isOpen",true);
                        //helper.createSObject(component,event,helper);
                    }else if(lstComponents[i].actionType == 'Embed VF Page'){
                        component.set("v.objectApiName",lstComponents[i].sObjectName);
                        component.set("v.isOpen",true);
                    }else if(lstComponents[i].actionType == 'Embed a Flow'){
                        component.set("v.isOpen",true);
                    }
                }                
            }
        }
    },
    closeModal : function(component,event,helper){
        component.set("v.isOpen",false);
    },
})