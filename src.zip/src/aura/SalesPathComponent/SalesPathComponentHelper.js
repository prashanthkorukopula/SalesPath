({
	createSObject : function(component, event, helper) {
        var recId = component.get("v.recordId");       
        var object = component.get("v.objectApiName");
		var createEvent = $A.get("e.force:createRecord");
        if(createEvent){
            createEvent.setParams({
                'entityApiName':object,
                
            });
            createEvent.fire();
        }else{
            alert('create unsuccessful');
        }
	},
    
})