({
	doInit : function(component, event, helper) {
		var createEvent = $A.get("e.force:createRecord");
        if(createEvent){
            createEvent.setParams({
                'entityApiName':'Task',
                'defaultFieldValues':{
                    'WhatId':'0017F00000oKh0kQAC'
                }
            });
            createEvent.fire();
        }else{
            alert('create unsuccessful');
        }
	}
})