({
	createTransactions : function(component,event,helper) {
		var recId = component.get("v.recordId");
        console.log('--recId'+recId);
        var action = component.get("c.saveTransactionRecords");
        action.setParams({
            recordId:recId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                console.log('--success');
            }else{
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action);
	}
})