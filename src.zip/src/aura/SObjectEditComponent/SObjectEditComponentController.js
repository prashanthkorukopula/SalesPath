({
	/* Method Name: saveSobject
     * Description: Controller method to handle save button click
	 */
	saveSobject : function(component, event, helper) {
		// Submittinng the form update action
		component.find("SobjectEditForm").submit();
		
	},
	/* Method Name: handleCancel
     * Description: Controller method to handle handle cancel button click
	 */
	handleCancel : function(component, event, helper){
		helper.fireFormEvent(component, event, helper);
	},
	/* Method Name: handleSuccess
     * Description: Controller method to handle handle form success
	 */
	handleSuccess : function(component, event, helper) {
		helper.fireFormEvent(component, event, helper);
	}
})