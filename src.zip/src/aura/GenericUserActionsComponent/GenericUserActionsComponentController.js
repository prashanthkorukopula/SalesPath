({
	doInit : function(component, event, helper) {
        var action = component.get("v.instanceUrl");
        var action1 = component.get("v.objectApiName");
        console.log(action1+'generic--'+action);
        
	}
})