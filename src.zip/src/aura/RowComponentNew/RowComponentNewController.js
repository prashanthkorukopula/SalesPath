({
  /* Method Name: doInit
   * Description: Controller method to dynamically render the row data based on the metdata passed to the function
   */
	doInit : function(component, event, helper) {
       // Fetching the metadata passed to the component
       var constructComponentData = component.get("v.rowComponentData");
       // Calling the method for dynamic component creation
       helper.constructComponents(component, constructComponentData);
	},

  /* Method Name: handleUserAction
   * Description: Generic Controller method to handle all user actions
   */
  handleUserAction: function(component, event, helper) {
      console.log('--userAction--',event.getSource());
      var newSObjectComponent = component.find("userAction");
      newSObjectComponent.createRecordFromParent();
  }
})