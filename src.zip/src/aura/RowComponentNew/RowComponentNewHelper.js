({	
	/* Method Name: constructComponents
     * Description: Helper Method to construct Component Data
     */
	constructComponents : function(component, rowComponent) {
		// Looping over the set of Component Data
        if(rowComponent != null && rowComponent != undefined){
            var body = [];
            //var componentList = rowComponent.lstComponentData;
            //componentList.sort(function(a,b){return a['componentOrder']-b['componentOrder'] ;});
    		for (var index in rowComponent.lstComponentData){
    			// Attributes of the Component    			
                var attributes = rowComponent.lstComponentData[index].mapAttributeValues;
                // Adding event listeners to the component dynamically
                for(var eventName in rowComponent.lstComponentData[index].mapEventAttributeValues){
                    attributes[eventName] = component.getReference(rowComponent.lstComponentData[index].mapEventAttributeValues[eventName]);
                }
                // Creating component
                $A.createComponent(rowComponent.lstComponentData[index].componentName, attributes, function(newComponent, status, errorMessage){
                    //Check if the action is successful
                    if (status === "SUCCESS") {
                    	// Check if the component is valid
                        if (component.isValid()) {                          
                            body.push(newComponent);
                            if(rowComponent.lstComponentData.length-1==index){
                              component.set("v.body", body);  
                            }
                            
                        }
                    }
                });
            }
            
		}
	}
})