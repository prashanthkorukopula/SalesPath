({
	/*
     * function name : showToastMessage
     * parameters    : toastType -> success/error/info/warning, toastMessage -> message to be displayed
     * return value  : none
     * description   : displays message in the event of success/failure of an action
     */
    showToastMessage : function(component, toastType, toastMessage){
        var showToastEvent = $A.get("e.force:showToast");
        showToastEvent.setParams({
            type: toastType,
            message: toastMessage,
            mode: "dismissible"
        });
        showToastEvent.fire();
	},
    createTransactions : function(component,event,helper) {
		var recId = component.get("v.recordId");
        console.log('--recId1'+recId);
        var action = component.get("c.saveTransactionRecords");
        action.setParams({
            recordId:recId
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                console.log('--success');
            }else{
                var errors = response.getError();
                alert(errors[0].message);
            }
        });
        $A.enqueueAction(action);
	}
})