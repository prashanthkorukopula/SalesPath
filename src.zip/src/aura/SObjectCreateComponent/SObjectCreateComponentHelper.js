({
    /*
     * function name : showToastMessage
     * parameters    : toastType -> success/error/info/warning, toastMessage -> message to be displayed
     * return value  : none
     * description   : displays message in the event of success/failure of an action
     */
    showToastMessage : function(component, toastType, toastMessage){
        var showToastEvent = $A.get("e.force:showToast");
        showToastEvent.setParams({
            type: toastType,
            message: toastMessage,
            mode: "dismissible"
        });
        showToastEvent.fire();
	},
})