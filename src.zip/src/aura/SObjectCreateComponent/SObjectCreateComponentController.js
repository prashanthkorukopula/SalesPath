({
    /* Method Name: handleSubmit
     * Description: Controller method to handle handleSubmit button click
	 */
    handleSubmit : function(component, event, helper) {
        // Prevent default submit
        event.preventDefault();
        // Prepopulate Description field
        var fields = event.getParam("fields");
        //fields["Description"] = 'This is a default description';
        //Submit form 
        component.find('createSobjectForm').submit(fields);
        component.set("v.isModal",false);        
        helper.showToastMessage(component, "success", "Data saved successfully");
    },
    
})